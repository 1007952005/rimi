/**
 * 功能：无缝图片轮播功能
 * 日期：2017/3/27
 **/
// 定义图片动画全局变量
let slideImg;

/* 页面加载完成后执行 */
$(function () {
	// banner容器
	let $banner = $(".banner");
	
	// 设置banner高度
	setBannerHeight($banner);
	
	// 显示第一张图片
	$banner.children().first().addClass("show");
	
	// 克隆原始图片列表
	let originImgList = $banner.children().clone();
	
	// 生成图片切换控制点
	createCtrlPointer();
	
	// 调用图片启动动画
	startImgAnimate();
	
	// 上下翻页
	flipImgPage();
	
	// 控制点切换图片
	pointerCtrlShow();
	
	/* 鼠标进入Banner */
	$("header").mouseenter(function () {
		// 停止动画
		stopImgAnimate()
	});
	
	/* 鼠标移出Banner */
	$("header").mouseleave(function () {
		// 开始动画
		startImgAnimate($banner);
	});
	/* 页面缩事件 */
	$(window).resize(function () {
		setBannerHeight($banner);
	});
});
/**
 * 功能：设置banner高度
 * 参数：banner标识符
 **/
function setBannerHeight(ident) {
	// 获取banner宽度
	let bannerWidth = ident.width();
	ident.height(bannerWidth / 3 + "px");
}

/**
 * 功能：图片轮播动画（启动）
 * 参数：banner标识符
**/
function startImgAnimate() {
	slideImg = setInterval(function () {
		showNextImg();
	},5000);
}
/**
* 功能：图片轮播动画（停止）
**/
function stopImgAnimate() {
	clearInterval(slideImg);
}

/**
 * 功能：上下一张图片翻页
 **/
function flipImgPage() {
	/* 点击显示下一张 */
	$(".next").click(function () {
		showNextImg();
	});
	/* 点击显示上一张 */
	$(".prev").click(function () {
		showPrevImg();
	});
}

/**
 * 功能：生成图片切换控制点
 * **/
function createCtrlPointer() {
	let imgList = $(".banner").children();
	imgList.each(function () {
		$(".ctrlItem").append("<i></i>");
	});
	$(".ctrlItem i:first").addClass("ckd");
}

/**
 * 功能：显示下一张图片
 **/
function showNextImg() {
	// 查找显示的图片
	let showImg = $(".banner").children(".show");
	// 需要克隆的元素
	var cloneImg;
	$(".banner .show").animate({"left": "-100%"},
		600, function () {
			$(this).removeClass("show").css("left", "100%");
			cloneImg = $(this);
			$(this).remove();
		})
		.next().animate({"left": "0%"},
		600, function () {
			$(this).addClass("show");
			$(".banner").append(cloneImg);
		});
	
	// 控制点子元素列表
	let $ctrlPointerDiv = $(".ctrlItem");
	let pointerList = $ctrlPointerDiv.children();
	let pointerListLeng = pointerList.length;
	let ckdPointer = $ctrlPointerDiv.children("i.ckd");
	if(ckdPointer.next().length !== 0) {
		ckdPointer.removeClass("ckd").next().addClass("ckd");
	} else {
		pointerList.eq(pointerListLeng - 1).removeClass("ckd");
		pointerList.eq(0).addClass("ckd");
	}
}

/**
 * 功能：显示上一张图片
 **/
function showPrevImg() {
	let $banner = $(".banner");
	// 查找显示的图片
	let showImg = $banner.children(".show");
	// 需要克隆的元素
	let cloneImg = $banner.children().last();
	cloneImg.css("left", "-100%");
	$banner.children().last().remove();
	$banner.prepend(cloneImg);
	showImg.animate({"left": "100%"},
		300, function () {
			$(this).removeClass("show");
		})
		.prev().animate({"left": "0%"},
		300, function () {
			$(this).addClass("show");
		});
	
	// 控制点子元素列表
	let $ctrlPointerDiv = $(".ctrlItem");
	let pointerList = $ctrlPointerDiv.children();
	let pointerListLeng = pointerList.length;
	let ckdPointer = $ctrlPointerDiv.children("i.ckd");
	if(ckdPointer.prev().length !== 0) {
		ckdPointer.removeClass("ckd").prev().addClass("ckd");
	} else {
		pointerList.eq(0).removeClass("ckd");
		pointerList.eq(pointerListLeng - 1).addClass("ckd");
	}
}


/**
 * 功能：控制点切换图片
 **/
function pointerCtrlShow() {

}